# Mahesh Borkar Portfolio
This is a simple HTML portfolio ready for GitHub Pages.